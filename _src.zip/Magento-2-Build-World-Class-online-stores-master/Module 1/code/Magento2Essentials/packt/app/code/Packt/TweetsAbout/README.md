## Synopsis

TweetsAbout Magento 2.0 module.

## License

[Open Source License](LICENSE.txt)
